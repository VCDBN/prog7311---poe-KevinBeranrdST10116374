using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using static ST10116374_PROG7311_POE.Pages.ProductsandFarmers.ProductsandFarmersModel;

namespace ST10116374_PROG7311_POE.Pages.ProductsandFarmers
{
    public class NewFamerModel : PageModel
    {
        //calls the list from index
        public FarmerInfo listFarmer = new FarmerInfo();
        public string errorMessage = "";          //calls error message when user enter wrong into the app
        public string succesMesage = "";          //calls succes message when user enter the right inputs into the app
        public void OnGet()
        {
        }

        public void Onpost(int studyhrs)
        {
            listFarmer.Fname = Request.Form["faname"];//this block is used to get the data from the web and make it know where to go
            listFarmer.Fpassword = Request.Form["fapassword"];

            if (listFarmer.Fname.Length == 0 || listFarmer.Fpassword.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            //save the client into the database
            try
            {
                //This is the sql connection string you will need to change this to connect to the database
                string connectionString = "Data Source=lab000000\\SQLEXPRESS;Initial Catalog=FarmDB;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "INSERT INTO Farmers" +
                                 "(Fname, Fpassword) VALUES " +
                                 "(@faname, @fapassword)";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        //these will insert the data both into the list and database
                        command.Parameters.AddWithValue("@faname", listFarmer.Fname);
                        command.Parameters.AddWithValue("@fapassword", listFarmer.Fpassword);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
            listFarmer.Fname = ""; listFarmer.Fpassword = "";
            succesMesage = "New Farmer Added Successfully";


        }
    }
}
