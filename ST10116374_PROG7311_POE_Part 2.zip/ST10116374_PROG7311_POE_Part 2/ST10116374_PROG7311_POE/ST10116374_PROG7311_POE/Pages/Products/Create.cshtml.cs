using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static ST10116374_PROG7311_POE.Pages.ProductsandFarmers.ProductsandFarmersModel;
using System.Data.SqlClient;

namespace ST10116374_PROG7311_POE.Pages.Products
{
    public class CreateModel : PageModel
    {
        //calls the list from index
        public ProdcutInfo listProducts = new ProdcutInfo();
        public string errorMessage = "";          //calls error message when user enter wrong into the app
        public string succesMesage = "";          //calls succes message when user enter the right inputs into the app
        public void OnGet()
        {
        }

        public void Onpost(int studyhrs)
        {
            listProducts.Farmers_Name = Request.Form["fapname"];//this block is used to get the data from the web and make it know where to go
            listProducts.name = Request.Form["pname"];
            listProducts.type = Request.Form["ptype"];

            if (listProducts.Farmers_Name.Length == 0 || listProducts.name.Length == 0 || listProducts.type.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            //save the client into the database
            try
            {
                //This is the sql connection string you will need to change this to connect to the database
                string connectionString = "Data Source=lab000000\\SQLEXPRESS;Initial Catalog=FarmDB;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "INSERT INTO Products" +
                                 "(Farmers_Name, name, type) VALUES " +
                                 "(@fapname, @pname, @ptype)";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        //these will insert the data both into the list and database
                        command.Parameters.AddWithValue("@fapname", listProducts.Farmers_Name);
                        command.Parameters.AddWithValue("@pname", listProducts.name);
                        command.Parameters.AddWithValue("@ptype", listProducts.type);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
            listProducts.Farmers_Name = ""; listProducts.name = ""; listProducts.type = "";
            succesMesage = "New Product Added Successfully";


        }
    }
}
