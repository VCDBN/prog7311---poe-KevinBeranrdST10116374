using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static ST10116374_PROG7311_POE.Pages.ProductsandFarmers.ProductsandFarmersModel;
using System.Data.SqlClient;

namespace ST10116374_PROG7311_POE.Pages.Products
{
    public class IndexModel : PageModel
    {
        //These are list for connect sending and receiving data
        public List<FarmerInfo> listFarmer = new List<FarmerInfo>();
        public List<ProdcutInfo> listProducts = new List<ProdcutInfo>();
        public void OnGet()
        {
            try
            {
                //This is the sql connection string you will need to change this to connect to the database there is one in login.cshtml.cs, Register.cshtml.cs, Setday.cshtml.cs, edit.cshtml.cs, create.cshtml.cs, delete.cshtml, deletesetday.cshtml
                string connectionString = "Data Source=lab000000\\SQLEXPRESS;Initial Catalog=FarmDB;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "SELECT * FROM Products"; //this is the sql query to make the data from the database table modules appear in the web app
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read()) //This reads from the database and outputs it to the web app
                            {
                                ProdcutInfo prodcutInfo = new ProdcutInfo();
                                prodcutInfo.idp = "" + reader.GetInt32(0);
                                prodcutInfo.Farmers_Name = reader.GetString(1);
                                prodcutInfo.name = reader.GetString(2);
                                prodcutInfo.type = reader.GetString(3);

                                listProducts.Add(prodcutInfo);//adds the data to the list
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString);
            }

        }
        //these two methods hold the needed requiremnets for the database and lists
        public class ProdcutInfo
        {
            public string idp;
            public string Farmers_Name;
            public string name;
            public string type;
        }
    }
}
