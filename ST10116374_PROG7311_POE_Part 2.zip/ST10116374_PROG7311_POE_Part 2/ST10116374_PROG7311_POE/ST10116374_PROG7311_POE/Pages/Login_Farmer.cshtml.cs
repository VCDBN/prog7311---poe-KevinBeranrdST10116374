using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using static ST10116374_PROG7311_POE.Pages.ProductsandFarmers.ProductsandFarmersModel;

namespace ST10116374_PROG7311_POE.Pages
{
    public class Login_FarmerModel : PageModel
    {
       //calls the list from index
        public FarmerInfo farmerinfo = new FarmerInfo();
        public string errorMessage = "";
        public string succesMesage = "";
        public void OnGet()
        {
            
        }
        public void OnPost() 
        {
            farmerinfo.Fname = Request.Form["name"];
            farmerinfo.Fpassword = Request.Form["password"];

            if (farmerinfo.Fname.Length == 0 || farmerinfo.Fpassword.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            //save the client into the database
            try
            {
                //This is the sql connection string you will need to change this to connect to the database
                string connectionString = "Data Source=lab000000\\SQLEXPRESS;Initial Catalog=FarmDB;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "SELECT * FROM Farmers" ;//this is used to validate the user is inputed correclt or if they need to register
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (ModelState.IsValid) //This reads from the database and outputs it to the web app
                            {
                               
                                Response.Redirect("/Products/Index");

                            }
                            else
                            {
                                Response.Redirect("/Index");
                            }
                        }
                       
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

        }


    }
}
