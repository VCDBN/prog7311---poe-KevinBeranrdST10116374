﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static ST10116374_PROG7311_POE.Pages.ProductsandFarmers.ProductsandFarmersModel;

namespace ST10116374_PROG7311_POE.Pages
{
    public class IndexModel : PageModel
    {
        public List<EmployeeInfo> employeeinfo = new List<EmployeeInfo>();
        public List<FarmerInfo> farmerinfo = new List<FarmerInfo>();
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }
        public class EmployeeInfo
        {
            public string name;
            public string password;
        }
    }
}