using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static ST10116374_PROG7311_POE.Pages.IndexModel;
using System.Data.SqlClient;
using static ST10116374_PROG7311_POE.Pages.ProductsandFarmers.ProductsandFarmersModel;
using System.Reflection.PortableExecutable;

namespace ST10116374_PROG7311_POE.Pages
{
    public class Login_EmployeeModel : PageModel
    {
        //calls the list from index
        public EmployeeInfo employeeinfo = new EmployeeInfo();
        public string errorMessage = "";
        public string succesMesage = "";
        public void OnGet()
        {
            
        }
        public void OnPost() 
        {
            employeeinfo.name = Request.Form["name"];
            employeeinfo.password = Request.Form["password"];

            if (employeeinfo.name.Length == 0 || employeeinfo.password.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            //save the client into the database
            try
            {
                //This is the sql connection string you will need to change this to connect to the database
                string connectionString = "Data Source=lab000000\\SQLEXPRESS;Initial Catalog=FarmDB;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "SELECT * FROM Employee";//this is used to validate the user is inputed correclt or if they need to register
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read()) //This reads from the database and outputs it to the web app
                            {
                                EmployeeInfo employeeInfo = new EmployeeInfo();
                                employeeInfo.name = "Kevin";
                                employeeInfo.password = "2222";
                                Response.Redirect("/ProductsandFarmers/Index");

                            }
                            else
                            {
                                Response.Redirect("/Index");
                            }
                        }
                       
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
        }
        
    }
   
}
